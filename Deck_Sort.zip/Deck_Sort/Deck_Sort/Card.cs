﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deck_Sort
{
  public class Card: IComparable<Card>
    {
        public enum SUIT
        {
            Diamond,
            Spades,
            Clubs,
            Hearts,
        }

        public enum FACE
        {
            Ace,
            Two,
            Three,
            Four,
            Five,
            Six,
            Seven,
            Eight,
            Nine,
            Ten,
            Jack,
            Queen,
            King,

        }

        public FACE Face;
        public SUIT Suit;

        public Card(FACE face, SUIT suit)
        {
            Face = face;
            Suit = suit;
        }

        public int CompareTo(Card other)
        {
            if (Suit > other.Suit)
            {
                return 1;
            }
            if (Suit < other.Suit)
            {
                return -1;
            }
            return Face > other.Face ? 1 : -1;
        }

        public override string ToString()
        {
            return $"{Face} of {Suit}";
        }
    }
}
