﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Deck_Sort.Card;

namespace Deck_Sort
{
    public class Deck
    {
        public List<Card> Cards;

        public Deck()
        {
            Cards = new List<Card>();
            int numSuits = Enum.GetNames(typeof(SUIT)).Length;
            int numKinds = Enum.GetNames(typeof(FACE)).Length;

            for (int suit = 0; suit < numSuits; suit++)
            {
                for (int kind = 0; kind < numKinds; kind++)
                {
                    Cards.Add(new Card((FACE)kind, (SUIT)suit));
                }
            }
        }

        public int CountCardsInDeck => Cards.Count;

        public void Shuffle()
        {

            Random random = new Random();
            int n = CountCardsInDeck;
            while (n > 1)
            {
                n--;
                int k = random.Next(n + 1);
                Card randomCard = Cards[k];
                Cards[k] = Cards[n];
                Cards[n] = randomCard;
            }
        }

        public void Sort() => Cards.Sort();

        public void Sort(IComparer<Card> comparer) => Cards.Sort(comparer);

        public void WriteToConsole()
        {
            foreach (Card card in Cards)
            {
                Console.WriteLine(card);
            }
        }
    }
}
