﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deck_Sort
{
   public class Program
    {
        static void Main(string[] args)
        {
            Deck cardDeck = new Deck();

            CardSorter sorter = new CardSorter
            {
                SortBy = CardSorter.CardOrderMethod.FaceThenSuit
            };
            
            cardDeck.Shuffle();
            cardDeck.Sort(sorter);
            Console.WriteLine("---Sorted deck: Face Then Suit---");
            cardDeck.WriteToConsole();
            Console.ReadKey();
        }
    }
}
