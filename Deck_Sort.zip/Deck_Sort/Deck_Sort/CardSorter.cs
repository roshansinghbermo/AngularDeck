﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deck_Sort
{
   public class CardSorter: IComparer<Card>
    {
      public  enum CardOrderMethod
        {
            SuitThenFace,
            FaceThenSuit,
        }

        public CardOrderMethod SortBy = CardOrderMethod.SuitThenFace;

        public int Compare(Card x, Card y)
        {
            if (SortBy == CardOrderMethod.SuitThenFace)
            {
                if (x.Suit > y.Suit)
                {
                    return 1;
                }
                if (x.Suit < y.Suit)
                {
                    return -1;
                }
                return x.Face > y.Face ? 1 : -1;
            }
            if (SortBy == CardOrderMethod.FaceThenSuit)
            {
                if (x.Face > y.Face)
                {
                    return 1;
                }
                if (x.Face < y.Face)
                {
                    return -1;
                }
                return x.Suit > y.Suit ? 1 : -1;
            }
            throw new NotImplementedException($"CardOrderMethod {SortBy} is not implemented.");
        }
    }
}

